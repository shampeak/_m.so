# Change Log
All notable changes to this package wil be docuented in this file.

## [Unreleased][unreleased]

## [2.0.0] - 2015-01-01
### Added
- Inital release

